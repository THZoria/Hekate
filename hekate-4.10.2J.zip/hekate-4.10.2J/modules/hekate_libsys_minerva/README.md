# Minerva Training Cell

### Custom Nvidia Tegra X1 DRAM trainer.

For more, check [Here](https://github.com/CTCaer/minerva_tc).



```
Minerva Training Cell (C) 2018 CTCaer.

/* Pain... And suffering. */
```
